// ── SOUND ──
function beep(f1,f2,dur,vol,type){try{var c=new(window.AudioContext||window.webkitAudioContext)();var o=c.createOscillator(),g=c.createGain();o.connect(g);g.connect(c.destination);o.type=type||'sine';o.frequency.value=f1;if(f2)o.frequency.linearRampToValueAtTime(f2,c.currentTime+dur);g.gain.value=vol||0.15;g.gain.linearRampToValueAtTime(0.001,c.currentTime+dur);o.start();o.stop(c.currentTime+dur+0.01);setTimeout(function(){c.close();},(dur+0.2)*1000);}catch(e){}}
function sClick(){beep(600,800,0.06,0.12);}
function sSuccess(){beep(523,0,0.1,0.12);setTimeout(function(){beep(659,0,0.1,0.12);},90);setTimeout(function(){beep(784,0,0.15,0.12);},180);}
function sError(){beep(220,110,0.2,0.2,'triangle');}
function sCopy(){beep(880,1100,0.1,0.15);}
function sPop(){beep(500,250,0.1,0.15);}
function sKoala(){try{var c=new(window.AudioContext||window.webkitAudioContext)();function munch(t,f){var o=c.createOscillator(),g=c.createGain();o.connect(g);g.connect(c.destination);o.type='sine';o.frequency.value=f;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(0.15,t+0.03);g.gain.exponentialRampToValueAtTime(0.001,t+0.12);o.start(t);o.stop(t+0.13);}var t=c.currentTime;munch(t,380);munch(t+0.15,420);munch(t+0.28,360);munch(t+0.42,400);setTimeout(function(){c.close();},1000);}catch(e){}}

// ── DISPATCH ──
document.addEventListener('click', function(e) {
  var el = e.target.closest('[data-act]');
  if (el) { sClick(); dispatch(el.getAttribute('data-act'), el); return; }
  var abtn = e.target.closest('.abtn');
  if (abtn) { sClick(); pickAI(abtn); }
});

function dispatch(a, el) {
  if (a==='back')           return back();
  if (a==='showLoad')       return show('load');
  if (a==='showUpdate')     return show('update');
  if (a==='showEos')        return show('eos');
  if (a==='showMiner')      return show('miner');
  if (a==='showBroadcast')  return show('broadcast');
  if (a==='showSettings')   return show('settings');
  if (a==='doLoadContext')  return doLoadContext();
  if (a==='doPush')         return doPush();
  if (a==='doEOS')          return doEOS();
  if (a==='copyEos')        return copyEl('eosOut', el);
  if (a==='doMine')         return doMine();
  if (a==='sendToUpdate')   return sendToUpdate();
  if (a==='doBroadcast')    return doBroadcast();
  if (a==='doSave')         return doSave();
  if (a==='doSaveAdvanced') return doSaveAdvanced();
}

// ── NAV ──
function show(id) {
  document.getElementById('main').style.display = 'none';
  document.querySelectorAll('.panel').forEach(function(p){ p.classList.remove('on'); });
  var el = document.getElementById('p-'+id);
  if (el) el.classList.add('on');
  if (id === 'settings') loadSettings();
}
function back() {
  document.querySelectorAll('.panel').forEach(function(p){ p.classList.remove('on'); });
  document.getElementById('main').style.display = 'block';
}

// ── AI PICKER ──
function pickAI(btn) {
  var group = btn.getAttribute('data-group');
  document.querySelectorAll('[data-group="'+group+'"]').forEach(function(b){ b.classList.remove('on'); });
  btn.classList.add('on');
}
function getAI(group) {
  var s = document.querySelector('[data-group="'+group+'"].on');
  return s ? s.textContent.trim() : 'Generic';
}

// ── STORY ──
var STORIES=["gumnuts wakes up","gumnuts meets kelly","the memory tree","a shadow in the creek","gumnuts brings a leaf","craig appears","craig makes his move","gumnuts stands firm","kelly has a plan","the first memory stolen","gumnuts panics","kelly finds a clue","gumnuts confesses","to be continued...","the donation unlocked this","kelly fights back","gumnuts trains","craig's lair","the heist","gumnuts gets caught","kelly to the rescue","the memory bubbles burst","gumnuts remembers everything","craig's sad backstory","gumnuts forgives craig","the memory tree blooms","kelly says something","gumnuts & kelly forever"];

chrome.runtime.sendMessage({type:'GET_STORY_STATE'}, function(state) {
  if (!state) return;
  var day = Math.min(state.storyDay||1, 28);
  document.getElementById('day-btn').textContent = 'day '+day+' ▶';
  document.getElementById('story-day').textContent = 'day '+day+' of 28';
  document.getElementById('story-name').textContent = STORIES[day-1]||'';
});

document.getElementById('day-btn').addEventListener('click', function() {
  chrome.tabs.create({ url: chrome.runtime.getURL('story.html') });
});
document.getElementById('story-bar').addEventListener('click', function() {
  chrome.tabs.create({ url: chrome.runtime.getURL('story.html') });
});

// ── LOAD CONTEXT ──
function doLoadContext() {
  var st = document.getElementById('loadStatus');
  chrome.storage.local.get(['devMode','githubToken','githubRepo','userName','userProjects'], function(d) {
    if (d.devMode && d.githubToken && d.githubRepo) {
      st.textContent = 'fetching...'; st.className = 'status';
      fetch('https://raw.githubusercontent.com/'+d.githubRepo+'/main/CLAUDE_CONTEXT.md', {
        headers: { Authorization: 'token '+d.githubToken }
      }).then(function(r){ return r.ok ? r.text() : Promise.reject(); })
      .then(function(text){
        navigator.clipboard.writeText(text);
        st.textContent = '✓ copied — paste into your AI chat'; st.className = 'status ok'; sSuccess();
      }).catch(function(){ st.textContent = '✗ fetch failed — check settings'; st.className = 'status err'; sError(); });
    } else {
      var prompt = 'Hi! My name is '+(d.userName||'your name')+' and I\'m working on: '+(d.userProjects||'my projects')+'.\n\nPlease acknowledge you\'re ready to help, then ask what we\'re working on today.';
      navigator.clipboard.writeText(prompt);
      st.textContent = '✓ copied — paste into your AI chat'; st.className = 'status ok'; sSuccess();
    }
  });
}

// ── PUSH ──
function doPush() {
  var notes = document.getElementById('updateNotes').value.trim();
  var st = document.getElementById('updateStatus');
  if (!notes) { st.textContent = 'paste some notes first'; st.className = 'status err'; sError(); return; }
  var content = '\n\n## SESSION UPDATE — '+new Date().toLocaleString('en-AU')+' ['+getAI('updateAI')+']\n\n'+notes;
  chrome.storage.local.get(['devMode'], function(d) {
    if (d.devMode) {
      st.textContent = 'saving...'; st.className = 'status';
      chrome.runtime.sendMessage({type:'PUSH_GITHUB',content:content}, function(res) {
        st.textContent = res&&res.ok ? '✓ saved to cloud' : '✗ failed — check settings';
        st.className = 'status '+(res&&res.ok?'ok':'err');
        res&&res.ok ? sSuccess() : sError();
      });
    } else {
      var blob = new Blob([content],{type:'text/plain'});
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a'); a.href=url; a.download='gumnuts-'+new Date().toISOString().slice(0,10)+'.txt'; a.click();
      URL.revokeObjectURL(url);
      st.textContent = '✓ saved to file'; st.className = 'status ok'; sSuccess();
    }
  });
}

// ── EOS ──
function doEOS() {
  var ai = getAI('eosAI');
  var focus = document.getElementById('eosFocus').value.trim();
  var sfx = focus ? '\n\nFocus especially on: '+focus : '';
  var prompts = {
    Claude: 'Please mine this entire conversation and produce a structured session update for my CLAUDE_CONTEXT.md file.\n\nFormat:\n## SESSION UPDATE — [DATE] [TIME] [Claude]\n\n### Projects & Status\n### Technical Details\n### Business & Strategy\n### People\n### Pending Actions\n### Personal Notes\n### Everything Else\n\nBe thorough. Capture file paths, URLs, dollar amounts, decisions, action items.'+sfx,
    ChatGPT: 'Analyse this full conversation and produce a structured session summary. Sections: Projects & Status, Technical Details, Business & Strategy, People, Pending Actions, Personal Notes, Everything Else.'+sfx,
    Gemini: 'Review this conversation and create a detailed session summary covering what was accomplished, tech details, decisions, people, and action items.'+sfx,
    Grok: 'Mine this chat. Projects updated, tech details, business decisions, people, TODOs, memorable moments. Structured markdown, no fluff.'+sfx,
    Generic: 'Summarise this conversation: Projects & Status, Technical Details, Business & Strategy, People, Pending Actions, Personal Notes, Everything Else.'+sfx
  };
  var out = document.getElementById('eosOut');
  out.textContent = prompts[ai]||prompts.Generic;
  out.style.display = 'block';
  document.getElementById('eosCopyBtn').style.display = 'block';
  sSuccess();
}

// ── MINER ──
function doMine() {
  var input = document.getElementById('minerIn').value.trim();
  if (!input) { sError(); return; }
  var urls=(input.match(/https?:\/\/[^\s)>"]+/g)||[]).slice(0,8).join('\n');
  var paths=(input.match(/[A-Za-z]:\\[^\s"']+|\/[a-z][^\s"']{3,}/g)||[]).slice(0,8).join('\n');
  var dollars=(input.match(/\$[\d,.KMBkm]+[^\s]*/g)||[]).join(', ');
  var actions=(input.match(/\[\s*\]\s*.+/g)||[]).join('\n');
  var projects=[...new Set((input.match(/\b(Gumnuts)\b/g)||[]))].join(', ');
  var out='MINED SESSION\n'+'─'.repeat(24)+'\n';
  if(projects)out+='\nProjects: '+projects;
  if(dollars)out+='\nAmounts: '+dollars;
  if(urls)out+='\n\nURLs:\n'+urls;
  if(paths)out+='\n\nPaths:\n'+paths;
  if(actions)out+='\n\nAction items:\n'+actions;
  if(!projects&&!dollars&&!urls&&!paths&&!actions)out+='\nNothing found.';
  var el=document.getElementById('minerOut');
  el.textContent=out; el.style.display='block';
  document.getElementById('minerSend').style.display='block';
  sSuccess();
}
function sendToUpdate() {
  document.getElementById('updateNotes').value = document.getElementById('minerOut').textContent;
  back(); show('update'); sPop();
}

// ── BROADCAST ──
function doBroadcast() {
  var text = document.getElementById('broadcastText').value.trim();
  var st = document.getElementById('broadcastStatus');
  if (!text) { st.textContent = 'enter a prompt first'; st.className = 'status err'; sError(); return; }
  var hosts = ['claude.ai','chat.openai.com','gemini.google.com','grok.com','mistral.ai','perplexity.ai','copilot.microsoft.com'];
  chrome.tabs.query({}, function(tabs) {
    var ai = tabs.filter(function(t){ try{ return hosts.some(function(h){ return new URL(t.url).hostname.includes(h); }); }catch(e){ return false; }});
    if (!ai.length) { st.textContent = 'no AI tabs open'; st.className = 'status err'; sError(); return; }
    ai.forEach(function(t){ chrome.tabs.sendMessage(t.id, {type:'INJECT_PROMPT',text:text}, function(){}); });
    st.textContent = '✓ sent to '+ai.length+' tab'+(ai.length>1?'s':''); st.className = 'status ok'; sSuccess();
  });
}

// ── SETTINGS ──
function loadSettings() {
  chrome.storage.local.get(['userName','userProjects','githubToken','githubRepo'], function(d) {
    if (d.userName) document.getElementById('sName').value = d.userName;
    if (d.userProjects) document.getElementById('sProjects').value = d.userProjects;
    if (d.githubToken) document.getElementById('sToken').value = d.githubToken;
    if (d.githubRepo) document.getElementById('sRepo').value = d.githubRepo;
  });
}
function doSave() {
  chrome.storage.local.set({ userName: document.getElementById('sName').value.trim(), userProjects: document.getElementById('sProjects').value.trim() }, function() {
    var st = document.getElementById('saveStatus');
    st.textContent = '✓ saved'; st.className = 'status ok'; sSuccess();
  });
}
function doSaveAdvanced() {
  chrome.storage.local.set({ githubToken: document.getElementById('sToken').value.trim(), githubRepo: document.getElementById('sRepo').value.trim(), devMode: true }, function() {
    var st = document.getElementById('advStatus');
    st.textContent = '✓ saved'; st.className = 'status ok'; sSuccess();
  });
}

// ── COPY ──
function copyEl(id, btn) {
  var text = document.getElementById(id).textContent;
  navigator.clipboard.writeText(text).then(function() {
    sCopy(); var orig = btn.textContent; btn.textContent = '✓ copied!';
    setTimeout(function(){ btn.textContent = orig; }, 1500);
  });
}

// Play koala sound on load
setTimeout(sKoala, 300);
