// Open side panel on icon click - works on ALL pages including claude.ai
chrome.action.onClicked.addListener(function(tab) {
  chrome.sidePanel.open({ tabId: tab.id });
});

// Set side panel to open on action click
chrome.runtime.onInstalled.addListener(function(details) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  
  if (details.reason === 'install') {
    chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') });
  }
  chrome.storage.local.get(['installDate','storyDay','donated'], function(data) {
    if (!data.installDate) {
      chrome.storage.local.set({ installDate: Date.now(), storyDay: 1, donated: false, lastShown: 0 });
    }
  });
  chrome.alarms.create('dailyStory', { periodInMinutes: 1440 });
});

chrome.alarms.onAlarm.addListener(function(alarm) {
  if (alarm.name === 'dailyStory') {
    chrome.storage.local.get(['storyDay'], function(data) {
      chrome.storage.local.set({ storyDay: Math.min((data.storyDay||1)+1, 28) });
    });
  }
});

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.type === 'GET_STORY_STATE') {
    chrome.storage.local.get(['storyDay','donated','lastShown','installDate'], sendResponse);
    return true;
  }
  if (msg.type === 'SET_SHOWN') {
    chrome.storage.local.set({ lastShown: Date.now() });
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'PUSH_GITHUB') {
    chrome.storage.local.get(['githubToken','githubRepo'], function(cfg) {
      var token = cfg.githubToken, repo = cfg.githubRepo;
      if (!token || !repo) { sendResponse({ ok: false }); return; }
      var content = btoa(unescape(encodeURIComponent(msg.content)));
      fetch('https://api.github.com/repos/'+repo+'/contents/CLAUDE_CONTEXT.md', {
        headers: { Authorization: 'token '+token, Accept: 'application/vnd.github.v3+json' }
      }).then(function(r){ return r.ok ? r.json() : null; })
      .then(function(j){
        var body = { message: 'chore: update context via Gumnuts', content: content };
        if (j && j.sha) body.sha = j.sha;
        return fetch('https://api.github.com/repos/'+repo+'/contents/CLAUDE_CONTEXT.md', {
          method: 'PUT',
          headers: { Authorization: 'token '+token, 'Content-Type': 'application/json' },
          body: JSON.stringify(body)
        });
      }).then(function(r){ sendResponse({ ok: r.ok }); })
      .catch(function(){ sendResponse({ ok: false }); });
    });
    return true;
  }
});
