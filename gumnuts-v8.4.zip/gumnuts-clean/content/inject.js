chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.type !== 'INJECT_PROMPT') return;
  var text = msg.text;
  var done = false;

  // Try contenteditable first (Claude, Gemini)
  var ed = document.querySelector('[contenteditable="true"][data-testid], [contenteditable="true"].ProseMirror, [contenteditable="true"]');
  if (ed) {
    ed.focus();
    document.execCommand('insertText', false, text);
    done = true;
  }

  // Try textarea (ChatGPT, Grok, Perplexity, Copilot)
  if (!done) {
    var ta = document.querySelector('#prompt-textarea, textarea[placeholder], textarea');
    if (ta) {
      ta.focus();
      var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value');
      if (setter && setter.set) setter.set.call(ta, text);
      ta.dispatchEvent(new Event('input', { bubbles: true }));
      ta.dispatchEvent(new Event('change', { bubbles: true }));
      done = true;
    }
  }

  sendResponse({ ok: done });
  return true;
});
